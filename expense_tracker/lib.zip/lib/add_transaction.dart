import 'package:flutter/material.dart';

import 'bottom_navigation_bar.dart';

class AddTransaction extends StatefulWidget {
  const AddTransaction({super.key});
  @override
  State<StatefulWidget> createState() {
    return _AddTransaction();
  }
}

class _AddTransaction extends State<AddTransaction> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
          icon: Icon(Icons.arrow_back),
          onPressed: () {
            Navigator.pushReplacement(
              context,
              MaterialPageRoute(builder: (context) => Navigation()),
            );
          },
        ),
        title: Text(
          'Add Transaction',
          style: TextStyle(
            color: Colors.black,
            fontSize: 30,
            fontFamily: "Times new roman",
          ),
        ),
      ),
      body: Center(
        child: Column(
          children: [
            Padding(
              padding: EdgeInsets.all(20),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    textAlign: TextAlign.start,
                    'Title',
                    style: TextStyle(
                      fontSize: 20,
                      color: Colors.black,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  SizedBox(height: 10),
                  TextField(
                    decoration: InputDecoration(
                      prefixIcon: Container(
                        margin: EdgeInsets.symmetric(vertical: 0),
                        decoration: BoxDecoration(
                          border: Border(
                            right: BorderSide(color: Colors.grey, width: 1),
                          ),
                        ),
                        child: Icon(Icons.description_outlined),
                      ),
                      hintText: "  Enter Title",
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(10),
                      ),
                    ),
                  ),
                  Text(
                    textAlign: TextAlign.start,
                    'Amount',
                    style: TextStyle(
                      fontSize: 20,
                      color: Colors.black,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  SizedBox(height: 10),
                  TextField(
                    decoration: InputDecoration(
                      // prefixIcon: Icon(Icons.currency_rupee)
                      prefixIcon: Container(
                        margin: EdgeInsets.symmetric(vertical: 0),
                        decoration: BoxDecoration(
                          border: Border(
                            right: BorderSide(color: Colors.grey, width: 1),
                          ),
                        ),
                        child: Icon(Icons.currency_rupee),
                      ),
                      hintText: "  Enter Amount",
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(10),
                      ),
                    ),
                  ),
                  Text(
                    textAlign: TextAlign.start,
                    'Category',
                    style: TextStyle(
                      fontSize: 20,
                      color: Colors.black,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  SizedBox(height: 10),
                  DropdownButtonFormField<String>(
                    decoration: InputDecoration(
                      // prefixIcon: Icon(Icons.grid_view_rounded),
                      prefixIcon: Container(
                        margin: EdgeInsets.symmetric(vertical: 0),
                        decoration: BoxDecoration(
                          border: Border(
                            right: BorderSide(color: Colors.grey, width: 1),
                          ),
                        ),
                        child: Icon(Icons.grid_view_rounded),
                      ),
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(10),
                      ),
                    ),
                    hint: Text('Select Category'),
                    items: [
                      DropdownMenuItem(value: 'Food', child: Text('Food')),
                      DropdownMenuItem(
                        value: 'Shopping',
                        child: Text('Shopping'),
                      ),
                      DropdownMenuItem(value: 'Travel', child: Text('Travel')),
                      DropdownMenuItem(value: 'Salary', child: Text('Salary')),
                    ],
                    onChanged: (value) {},
                  ),
                  SizedBox(height: 10),
                  Text(
                    textAlign: TextAlign.start,
                    'Type',
                    style: TextStyle(
                      fontSize: 20,
                      color: Colors.black,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  SizedBox(height: 10),
                  Row(
                    children: [
                      Expanded(
                        child: Container(
                          padding: EdgeInsets.all(20),
                          height: 100,
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(10),
                            color: Colors.green,
                          ),
                          child: Row(
                            children: [
                              Icon(
                                Icons.add_circle_outline_outlined,
                                color: Colors.white,
                              ),
                              SizedBox(width: 10),
                              Text(
                                'Income',
                                style: TextStyle(
                                  color: Colors.white,
                                  fontSize: 20,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                      SizedBox(width: 10),
                      Expanded(
                        child: Container(
                          padding: EdgeInsets.all(20),
                          height: 100,
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(10),
                            color: Colors.grey,
                          ),
                          child: Row(
                            children: [
                              Icon(
                                Icons.remove_circle_outline,
                                color: Colors.white,
                              ),
                              SizedBox(width: 10),
                              Text(
                                'Expense',
                                style: TextStyle(
                                  color: Colors.white,
                                  fontSize: 20,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ],
                  ),
                  SizedBox(height: 10),
                  Text(
                    textAlign: TextAlign.start,
                    'Date',
                    style: TextStyle(
                      fontSize: 20,
                      color: Colors.black,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  SizedBox(height: 10),
                  DropdownButtonFormField<String>(
                    decoration: InputDecoration(
                      // prefixIcon: Icon(Icons.calendar_month_sharp),
                      prefixIcon: Container(
                        margin: EdgeInsets.symmetric(vertical: 0),
                        decoration: BoxDecoration(
                          border: Border(
                            right: BorderSide(color: Colors.grey, width: 1),
                          ),
                        ),
                        child: Icon(Icons.calendar_month_sharp),
                      ),
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(10),
                      ),
                    ),
                    hint: Text('Select Date'),
                    items: [
                      DropdownMenuItem(
                        value: '08/19/2025',
                        child: Text('08/19/2025'),
                      ),
                      DropdownMenuItem(
                        value: '09/19/2025',
                        child: Text('09/19/2025'),
                      ),
                      DropdownMenuItem(
                        value: '10/19/2025',
                        child: Text('10/19/2025'),
                      ),
                      DropdownMenuItem(
                        value: '11/19/2025',
                        child: Text('11/19/2025'),
                      ),
                      DropdownMenuItem(
                        value: '12/19/2025',
                        child: Text('12/19/2025'),
                      ),
                    ],
                    onChanged: (value) {},
                  ),
                  SizedBox(height: 10),
                  Text(
                    textAlign: TextAlign.start,
                    'Note(Optional)',
                    style: TextStyle(
                      fontSize: 20,
                      color: Colors.black,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  SizedBox(height: 10),
                  TextField(
                    decoration: InputDecoration(
                      prefixIcon: Container(
                        margin: EdgeInsets.symmetric(vertical: 0),
                        decoration: BoxDecoration(
                          border: Border(
                            right: BorderSide(color: Colors.grey, width: 1),
                          ),
                        ),
                        child: Icon(Icons.note_rounded),
                      ),
                      hintText: "  write Note",
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(10),
                      ),
                    ),
                  ),
                  SizedBox(height: 30),
                  SizedBox(
                    width: double.infinity,
                    height: 50,
                    child: ElevatedButton(
                      onPressed: () {},
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.green,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(10),
                        ),
                      ),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(
                            Icons.add_circle_outline_outlined,
                            color: Colors.white,
                            size: 20,
                          ),
                          SizedBox(width: 20),
                          Text(
                            'Add Transaction',
                            style: TextStyle(
                              color: Colors.white,
                              fontSize: 18,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
